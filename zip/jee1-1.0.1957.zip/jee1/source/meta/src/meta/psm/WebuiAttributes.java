/*
 * Este programa es software libre; usted puede redistribuirlo y/o modificarlo bajo los terminos
 * de la licencia "GNU General Public License" publicada por la Fundacion "Free Software Foundation".
 * Este programa se distribuye con la esperanza de que pueda ser util, pero SIN NINGUNA GARANTIA;
 * vea la licencia "GNU General Public License" para obtener mas informacion.
 */
package meta.psm;

import adalid.core.annotations.AddAttributesMethod;
import adalid.core.interfaces.Entity;

import static meta.psm.EntityAttributeKeys.CONSOLE_VIEW_WIDTH;
import static meta.psm.EntityAttributeKeys.DETAIL_VIEW_WIDTH;
import static meta.psm.EntityAttributeKeys.TABLE_VIEW_WIDTH;

/**
 * @author Jorge Campins
 */
public class WebuiAttributes {

    @AddAttributesMethod
    public static void addAttributes(Entity entity) {
        entity.addAttribute(TABLE_VIEW_WIDTH, 1200);
        entity.addAttribute(DETAIL_VIEW_WIDTH, 1200);
        entity.addAttribute(CONSOLE_VIEW_WIDTH, 1200);
    }

}
